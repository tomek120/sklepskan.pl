import unittest
from unittest.mock import patch
from bs4 import BeautifulSoup
import app as web
from network import outcome

BASE = 'http://127.0.0.1:5000'


def sample_report():
    checks = {name: outcome('unknown', message='Brak danych') for name in ['domain_age','tls','mx','spf','dmarc','legal_links']}
    return dict(technical_host='example.com', started_at='2026-11-12', final_url='https://example.com', checks=checks,
                seller=outcome('unknown', message='Nie ustalono sprzedawcy'), pages=[], findings=[], foreign_identifiers=[], limitations=['Bez JavaScript.'])


class WebTests(unittest.TestCase):
    def setUp(self):
        web.app.config['TESTING'] = True
        self.client = web.app.test_client()
        response = self.client.get('/', base_url=BASE)
        soup = BeautifulSoup(response.data, 'html.parser')
        self.token = soup.find('meta', attrs={'name':'csrf-token'})['content']

    def post(self, data):
        return self.client.post('/analyze', base_url=BASE, json=data, headers={'X-CSRF-Token': self.token})

    def test_form_and_assets(self):
        for path in ['/', '/static/style.css', '/static/app.js']:
            with self.client.get(path, base_url=BASE) as response:
                self.assertEqual(response.status_code, 200)

    def test_missing_token(self):
        self.assertEqual(self.client.post('/analyze', base_url=BASE, json={'address':'example.com'}).status_code, 403)

    def test_bad_address(self):
        for address in ['', [], None, 'x'*2049]:
            self.assertEqual(self.post({'address':address}).status_code, 400)

    def test_foreign_host(self):
        self.assertEqual(self.client.get('/', base_url='http://evil.example:5000').status_code, 400)

    def test_busy(self):
        web.scan_lock.acquire()
        try:
            self.assertEqual(self.post({'address':'example.com'}).status_code, 429)
        finally:
            web.scan_lock.release()

    def test_success_and_escaping(self):
        report = sample_report()
        report['technical_host'] = '<script>alert(1)</script>'
        report['findings'] = [dict(nip='5170441148', checksum_valid=True, vat=outcome('found', {'name':'Firma', 'vat_status':'Czynny'}), evidence=[])]
        with patch.object(web, 'analyze_shop', return_value=report):
            response = self.post({'address':'example.com'})
        self.assertEqual(response.status_code, 200)
        self.assertIn('Czynny', response.json['html'])
        self.assertNotIn('<script>', response.json['html'])
        self.assertEqual(response.json['report'], report)

    def test_no_html(self):
        with patch.object(web, 'analyze_shop', return_value=sample_report()):
            response = self.post({'address':'example.com'})
        self.assertIn('analiza NIP nie została wykonana', response.json['html'])

    def test_validation_releases_lock(self):
        with patch.object(web, 'analyze_shop', side_effect=ValueError('bad')):
            self.assertEqual(self.post({'address':'bad'}).status_code, 400)
        self.assertFalse(web.scan_lock.locked())

    def test_failure_releases_lock(self):
        with patch.object(web, 'analyze_shop', side_effect=RuntimeError('secret')), self.assertLogs(web.app.logger, level='ERROR'):
            response = self.post({'address':'example.com'})
        self.assertEqual(response.status_code, 500)
        self.assertNotIn('secret', response.json['error'])
        self.assertFalse(web.scan_lock.locked())

if __name__ == '__main__':
    unittest.main()
